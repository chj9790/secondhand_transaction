package com.boot.test.controller;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.test.model.ProductDTO;
import com.boot.test.model.TestMapper;

@Controller
public class TestController {

    // 행안부 서비스 키 (URL 인코딩된 형태)
    private final String serviceKey = "4nBujbp1E0ViGhmQ1OVbTAsvPVjcizGnRY6PaZFVNWDaoE%2FSpFduMy1Yyq3ZMf6PFyZyAbVJao%2FKsbOOPxDnzA%3D%3D";

    @Autowired
    private TestMapper mapper;

    @GetMapping("/")
    public String mainPage(
            @RequestParam(value = "area", required = false) String area,
            @RequestParam(value = "category_code", required = false) String category_code,
            @RequestParam(value = "keyword", required = false) String keyword,
            Model model) {

        Map<String, String> filters = new HashMap<>();
        filters.put("area", area);
        filters.put("category_code", category_code);
        filters.put("keyword", keyword);

        List<ProductDTO> products = mapper.selectProductsByFilter(filters);

        model.addAttribute("productList", products);
        model.addAttribute("selectedArea", area);
        model.addAttribute("selectedCategory", category_code);
        model.addAttribute("keyword", keyword);
        model.addAttribute("serviceKey", serviceKey);
        model.addAttribute("guName", (area != null && !area.isEmpty()) ? area : "일산동구");

        return "main";
    }
}
