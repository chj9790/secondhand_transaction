package com.boot.transaction.model;

import java.util.Date;

import lombok.Data;

@Data
public class UserDTO {

	private String user_id;
	private String user_pwd;
	private String user_name;
	private int user_age;
	private String user_email;
	private String user_phone;
	private String user_addr;
	private Date user_regdate;
}
