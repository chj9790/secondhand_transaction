package com.boot.transaction.model;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface TransactionMapper {

	List<ProductDTO> product_list(PageDTO pdto); // 기존의 메서드에 인자 추가
	
	List<ProductDTO> product_list_on_chat();	// 채팅 기능에서 사용할 인자 없는 상품 판매글 조회
	
	int products_count();
	
	List<ProductDTO> product_list_by_category(String categoryCode);
	
	List<CategoryDTO> category_list();
	
	int product_insert(ProductDTO pdto);
	
	List<ProductDTO> user_product_list(String user_id);
	
	int user_product_modify(ProductDTO pdto);
	
	int user_product_delete(int product_num);
	
	void product_num_seq(int product_num);
	
	int insertUser(UserDTO user);

	UserDTO findId(String user_id);
	
	int products_search_count(Map<String, String> map);

	List<ProductDTO> products_search_list(PageDTO pdto);
	
	ProductDTO selectProduct(int product_num);

	void insertWishList(@Param("user_id") String user_id, @Param("product_num") int product_num);

	void sendMessage(ChatMessageDTO cdto);
	
	List<ChatMessageDTO> getChatMessages(@Param("buyer_id") String buyer_id,
	        @Param("seller_id") String seller_id,
	        @Param("product_num") int product_num);
	
	List<ChatMessageDTO> myMessage(String user_id);
	
}
