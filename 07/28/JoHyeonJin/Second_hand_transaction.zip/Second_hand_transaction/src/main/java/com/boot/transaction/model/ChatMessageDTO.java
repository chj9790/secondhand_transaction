package com.boot.transaction.model;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class ChatMessageDTO {
    private Long message_id;       // MESSAGE_ID (시퀀스 자동 생성)
    private String from_user;      // FROM_USER
    private String to_user;        // TO_USER
    private Integer product_num;   // PRODUCT_NUM
    private String message;       // MESSAGE
    private LocalDateTime sent_time; // SENT_AT
    private boolean is_read;
    private Integer chat_room_num;
}

