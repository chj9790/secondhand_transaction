package com.boot.project.model;

import lombok.Data;

@Data
public class ProductDTO {
	
		private String product_code;
		private String category_code;
		private String product_name;
		private String product_date;
		private String product_img;
		private String userId;
		private Integer sales_price;
		private String sales_area;
		
}
