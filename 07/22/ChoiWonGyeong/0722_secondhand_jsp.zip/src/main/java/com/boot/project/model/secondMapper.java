package com.boot.project.model;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface secondMapper {
	
	List<ProductDTO> product_list(); // 전체 물품 리스트 조회 
	List<ProductDTO> product_list_by_category(String categoryCode); 
	List<CategoryDTO> category_list(); // 카테고리 별 리스트 조회

}
