package com.boot.project.model;

public class secondHand {

}
