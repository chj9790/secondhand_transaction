package com.boot.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import com.boot.project.model.ProductDTO;
import com.boot.project.model.secondMapper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class secondHandController {
	
	@Autowired
	private secondMapper mapper;
	
	@GetMapping("/")
	public String main(Model model) {
	
	
		List<ProductDTO> productlist = mapper.product_list(); // 전체 상품 조회하기
		
		System.out.println("조회된 상품 개수: " + productlist.size());
		
		
		model.addAttribute("productList", productlist);
		
		return "main";
		
	}
	
	

}
