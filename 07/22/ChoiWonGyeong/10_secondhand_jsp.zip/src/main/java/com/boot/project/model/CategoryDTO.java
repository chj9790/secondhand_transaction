package com.boot.project.model;

import lombok.Data;

@Data
public class CategoryDTO {

	Integer category_num;
	String category_code;
	String category_name;
	
	
}
