package com.boot.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import com.boot.project.model.CategoryDTO;
import com.boot.project.model.ProductDTO;
import com.boot.project.model.secondMapper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class secondHandController {
	
	@Autowired
	private secondMapper mapper;
	
	@GetMapping("/")
	public String main(
	    @RequestParam(value = "category_code", required = false) String categoryCode,
	    Model model) {

	    List<ProductDTO> productlist;
	    if(categoryCode == null || categoryCode.isEmpty()) {
	        productlist = mapper.product_list();  // 전체 제품
	    } else {
	        productlist = mapper.product_list_by_category(categoryCode);  // 카테고리별 제품
	    }

	    List<CategoryDTO> categorylist = mapper.category_list();

	    model.addAttribute("productList", productlist);
	    model.addAttribute("categoryList", categorylist);
	    model.addAttribute("selectedCategory", categoryCode);

	    return "main";  
	}

	
	

}
