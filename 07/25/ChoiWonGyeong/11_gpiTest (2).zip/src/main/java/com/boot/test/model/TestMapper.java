package com.boot.test.model;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface TestMapper {

	 // 구/동, 카테고리, 키워드로 검색
    List<ProductDTO> selectProductsByFilter(Map<String, String> filters);

    // 테스트용 전체 리스트
    List<ProductDTO> selectAllProducts();
	
	
}
