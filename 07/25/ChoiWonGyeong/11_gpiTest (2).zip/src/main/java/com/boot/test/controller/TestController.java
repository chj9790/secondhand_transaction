package com.boot.test.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Slf4j
@Controller
public class TestController {

    @Value("${juso.api.key}")
    private String confmKey;

    @GetMapping("/")
    public String mainPage() {
        return "main";
    }

    @GetMapping(value = "/juso", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<String> getJuso(@RequestParam("keyword") String keyword) {
        try {
            // 특수문자 제거 (SQL 예약어 및 문제되는 문자들)
            String safeKeyword = keyword.trim().replaceAll("[=><\\[\\]%]", "");

            UriComponentsBuilder builder = UriComponentsBuilder
                    .fromHttpUrl("https://business.juso.go.kr/addrlink/addrLinkApi.do")
                    .queryParam("confmKey", confmKey)
                    .queryParam("currentPage", "1")
                    .queryParam("countPerPage", "12")  // 고정값
                    .queryParam("keyword", safeKeyword)
                    .queryParam("resultType", "xml");

            String url = builder.toUriString();
            log.info("API 호출 URL: {}", url);

            RestTemplate restTemplate = new RestTemplate();
            String xmlResponse = restTemplate.getForObject(url, String.class);

            log.info("API 응답 내용: {}", xmlResponse);

            if (xmlResponse == null || xmlResponse.contains("<errorCode>")) {
                log.error("API 에러 응답: {}", xmlResponse);
                return new ArrayList<>();
            }

            return extractDongFromXML(xmlResponse);

        } catch (Exception e) {
            log.error("주소 API 호출 중 오류 발생", e);
            return new ArrayList<>();
        }
    }

    private List<String> extractDongFromXML(String xml) {
        Set<String> dongSet = new HashSet<>();

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new java.io.ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));

            NodeList jusoList = doc.getElementsByTagName("juso");

            for (int i = 0; i < jusoList.getLength(); i++) {
                Element juso = (Element) jusoList.item(i);
                String jibunAddr = juso.getElementsByTagName("jibunAddr").item(0).getTextContent();

                String[] parts = jibunAddr.split(" ");
                if (parts.length >= 3) {
                    String dong = parts[2];
                    dongSet.add(dong);
                }
            }

        } catch (Exception e) {
            log.error("XML 파싱 오류", e);
        }

        return new ArrayList<>(dongSet);
    }
}
