package com.boot.transaction.model;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TransactionMapper {

	List<ProductDTO> product_list(PageDTO pdto); // 기존의 메서드에 인자 추가

	int products_count();
	
	List<ProductDTO> product_list_by_category(String categoryCode);
	
	List<CategoryDTO> category_list();
	
	int product_insert(ProductDTO pdto);
	
	List<ProductDTO> user_product_list();	// 로그인 작업 이후 user_id를 인자로 추가할 예정.
	
	int insertUser(UserDTO user);

	UserDTO findId(String user_id);
	
}
