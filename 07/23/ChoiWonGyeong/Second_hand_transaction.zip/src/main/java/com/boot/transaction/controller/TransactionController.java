package com.boot.transaction.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.boot.transaction.model.CategoryDTO;
import com.boot.transaction.model.PageDTO;
import com.boot.transaction.model.ProductDTO;
import com.boot.transaction.model.TransactionMapper;
import com.boot.transaction.model.UserDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@Controller
public class TransactionController {

	@Autowired
	private TransactionMapper mapper;
	
	// 페이지 변수
    private final int rowsize = 10;
 	private int totalRecord = 0;
	
 	@GetMapping("/")
	public String main(@RequestParam(value = "page", defaultValue = "1") int page,
			@RequestParam(value = "category_code", required = false) String categoryCode,
			Model model) {
	
		totalRecord = this.mapper.products_count();
				
		PageDTO pdto = new PageDTO(page, rowsize, totalRecord);
	
		List<ProductDTO> productlist;
		
	    if(categoryCode == null || categoryCode.isEmpty()) {
	        productlist = mapper.product_list(pdto);  // 전체 제품
	    } else {
	        productlist = mapper.product_list_by_category(categoryCode);  // 카테고리별 제품
	    }	
		
		List<CategoryDTO> category = mapper.category_list();
		
		model.addAttribute("productList", productlist)
			.addAttribute("paging", pdto)	
			.addAttribute("category", category)
			.addAttribute("selectedCategory", categoryCode);
		
		return "main";
		
	}
	
	@GetMapping("user_my_page.go")
	public String my_page() {
		return "user_my_page";
	}
	
	
	@GetMapping("product_sales.go")
	public String product_sales(Model model) {
		
		List<CategoryDTO> categoryList = this.mapper.category_list();
		
		model.addAttribute("categoryList", categoryList);
		
		return "product_sales";
	}
	
	@PostMapping("product_sales_ok.go")
	public void product_sales_ok(ProductDTO pdto,
	                             HttpServletRequest request,
	                             HttpServletResponse response) throws IllegalStateException, IOException {

		response.setContentType("text/html; charset=UTF-8");
	    PrintWriter out = response.getWriter();
		
	    MultipartFile[] files = pdto.getProduct_img_File();
	    List<String> savedFileNames = new ArrayList<>();

	    if(files != null && files.length > 0) {
	        String uploadPath = request.getServletContext().getRealPath("resources/upload/");

	        for (MultipartFile file : files) {
	            if (!file.isEmpty()) {
	                String originalFileName = file.getOriginalFilename();

	                // 파일명 중복 방지
	                String uuid = UUID.randomUUID().toString();
	                String savedFileName = uuid + "_" + originalFileName;

	                File destFile = new File(uploadPath, savedFileName);
	                if (!destFile.getParentFile().exists()) {
	                    destFile.getParentFile().mkdirs();
	                }
	                savedFileNames.add(savedFileName);
	                file.transferTo(destFile);
	                	
	            }
	        }

	        String imgNames = String.join(",", savedFileNames);
	        pdto.setProduct_img(imgNames);
	    }

	    // DB insert
	    int insertCheck = this.mapper.product_insert(pdto);

	    if (insertCheck > 0) {
	        out.println("<script>");
	        out.println("alert('물품 등록 성공');");
	        out.println("location.href='/'");
	        out.println("</script>");
	    } else {
	        out.println("<script>");
	        out.println("alert('물품 등록 실패');");
	        out.println("history.back();");
	        out.println("</script>");
	    }
	}
	
	
	@GetMapping("user_sales_product_list.go")
	public String user_sales_product_list(Model model) {
		
		List<ProductDTO> user_product_list = this.mapper.user_product_list();
		
		model.addAttribute("user_product_list", user_product_list);
		
		return "user_my_sales_list";
		
	}
	
	
	// 회원가입 기능
	@GetMapping("/sign_up.go")
	public String signupForm(Model model) {	    
	    return "sign_up";
	}
	
    
    @PostMapping("/sign_up_ok.go")
    public void signupUser(UserDTO dto, HttpServletResponse response) throws IOException {
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        UserDTO duplicateUser = mapper.findId(dto.getUser_id());
        if (duplicateUser != null) {
            out.println("<script>");
            out.println("alert('이미 사용 중인 아이디입니다.');");
            out.println("history.back();");
            out.println("</script>");
            return;
        }
        
        int check = this.mapper.insertUser(dto);

        if(check > 0) {
            out.println("<script>");
            out.println("alert('회원 등록 성공!!!');");
            out.println("location.href='/'");
            out.println("</script>");
        } else {
            out.println("<script>");
            out.println("alert('회원 등록 실패!');");
            out.println("history.back();");
            out.println("</script>");
        }
        
    }
    
    @GetMapping("/check_id.go")
    public void checkId(@RequestParam("user_id") String id, HttpServletResponse response) throws IOException {
        response.setContentType("text/plain; charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        if (id == null || id.trim().isEmpty()) {
            out.println("아이디를 입력해주세요."); 
            return;
        }

        UserDTO duplicateUser = mapper.findId(id);

        if (duplicateUser != null) {
            out.println("이미 사용 중인 아이디입니다.");
        } else {
            out.println("사용 가능한 아이디입니다.");
        }
    }
	

}
