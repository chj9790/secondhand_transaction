package com.boot.transaction.model;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class PaymentDTO {
    private int payment_id;
    private String user_id;
    private int product_num;
    private int amount;
    private String payment_method;
    private String payment_status;
    private Timestamp paid_at;

}