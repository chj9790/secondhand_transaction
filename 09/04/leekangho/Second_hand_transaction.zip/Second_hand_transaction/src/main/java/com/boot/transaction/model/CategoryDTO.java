package com.boot.transaction.model;

import lombok.Data;

@Data
public class CategoryDTO {

	private int category_num;
	private String category_code;
	private String category_name;
	
}
