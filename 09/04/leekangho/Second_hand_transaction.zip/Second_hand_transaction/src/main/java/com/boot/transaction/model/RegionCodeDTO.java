package com.boot.transaction.model;

import lombok.Data;

@Data
public class RegionCodeDTO {
	
	
	private String code;
	private String name;
	private String is_active;

}